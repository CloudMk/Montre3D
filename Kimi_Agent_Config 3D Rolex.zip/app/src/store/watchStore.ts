import { create } from 'zustand';

export type MaterialType = 'steel' | 'gold' | 'rose-gold' | 'platinum';
export type DialColor = 'black' | 'blue' | 'green' | 'white' | 'champagne' | 'brown';
export type StrapType = 'oyster' | 'jubilee' | 'leather';

interface WatchState {
  // Customization options
  material: MaterialType;
  dialColor: DialColor;
  strapType: StrapType;
  
  // Actions
  setMaterial: (material: MaterialType) => void;
  setDialColor: (color: DialColor) => void;
  setStrapType: (type: StrapType) => void;
  
  // Price calculation
  getPrice: () => number;
}

const materialPrices: Record<MaterialType, number> = {
  steel: 8500,
  gold: 28500,
  'rose-gold': 29500,
  platinum: 42500,
};

const dialPrices: Record<DialColor, number> = {
  black: 0,
  blue: 500,
  green: 750,
  white: 0,
  champagne: 1000,
  brown: 500,
};

const strapPrices: Record<StrapType, number> = {
  oyster: 0,
  jubilee: 800,
  leather: 1200,
};

export const useWatchStore = create<WatchState>((set, get) => ({
  material: 'steel',
  dialColor: 'black',
  strapType: 'oyster',
  
  setMaterial: (material) => set({ material }),
  setDialColor: (dialColor) => set({ dialColor }),
  setStrapType: (strapType) => set({ strapType }),
  
  getPrice: () => {
    const state = get();
    return materialPrices[state.material] + 
           dialPrices[state.dialColor] + 
           strapPrices[state.strapType];
  },
}));

// Material configurations for 3D rendering
export const materialConfigs: Record<MaterialType, { color: string; metalness: number; roughness: number }> = {
  steel: { color: '#C0C0C0', metalness: 0.95, roughness: 0.15 },
  gold: { color: '#C9A961', metalness: 1.0, roughness: 0.1 },
  'rose-gold': { color: '#D4A574', metalness: 1.0, roughness: 0.1 },
  platinum: { color: '#E5E5E5', metalness: 0.98, roughness: 0.12 },
};

export const dialConfigs: Record<DialColor, { color: string; emissive?: string }> = {
  black: { color: '#0A0A0A' },
  blue: { color: '#1A365D' },
  green: { color: '#1C4532' },
  white: { color: '#F7F7F7' },
  champagne: { color: '#F5E6C8' },
  brown: { color: '#3D2817' },
};
