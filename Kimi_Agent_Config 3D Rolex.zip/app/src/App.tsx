import { Scene3D } from '@/components/3d/Scene3D';
import { LuxuryHeader } from '@/components/ui/custom/LuxuryHeader';
import { ControlPanel } from '@/components/ui/custom/ControlPanel';
import { ChevronDown, Sparkles, Shield, Award } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200">
      {/* Header */}
      <LuxuryHeader />

      {/* Hero Section */}
      <section className="relative min-h-screen pt-20">
        {/* Background gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F1419] via-transparent to-transparent opacity-50" />
        
        {/* Decorative elements */}
        <div className="absolute top-1/4 left-10 w-64 h-64 bg-[#C9A961]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-[#0F1419]/5 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Hero Title */}
          <div className="text-center mb-8 lg:mb-0">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#C9A961]/10 border border-[#C9A961]/20 mb-4">
              <Sparkles className="w-4 h-4 text-[#C9A961]" />
              <span className="text-sm text-[#C9A961] font-medium uppercase tracking-wider">
                Configuration en temps réel
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif text-[#0F1419] mb-4">
              Créez votre <span className="text-[#C9A961]">montre unique</span>
            </h1>
            <p className="text-lg text-[#8B8680] max-w-2xl mx-auto">
              Personnalisez chaque détail de votre Oyster Perpetual avec notre configurateur 3D. 
              Une expérience immersive pour créer la montre de vos rêves.
            </p>
          </div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center mt-8 lg:mt-12">
            {/* 3D Scene */}
            <div className="relative order-2 lg:order-1">
              <div className="relative aspect-square max-w-lg mx-auto">
                {/* Glow effect behind watch */}
                <div className="absolute inset-0 bg-gradient-radial from-[#C9A961]/20 via-transparent to-transparent rounded-full blur-2xl" />
                
                {/* 3D Canvas Container */}
                <div className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl border border-white/50 bg-gradient-to-br from-white/50 to-white/20 backdrop-blur-sm">
                  <Scene3D />
                </div>

                {/* Interactive hint */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-2 rounded-full bg-[#0F1419]/80 backdrop-blur-sm text-white text-sm">
                  <span className="w-2 h-2 rounded-full bg-[#C9A961] animate-pulse" />
                  Cliquez et faites glisser pour tourner
                </div>
              </div>
            </div>

            {/* Control Panel */}
            <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
              <ControlPanel />
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="hidden lg:flex justify-center mt-12">
            <a 
              href="#features" 
              className="flex flex-col items-center gap-2 text-[#8B8680] hover:text-[#C9A961] transition-colors"
            >
              <span className="text-sm uppercase tracking-widest">Découvrir plus</span>
              <ChevronDown className="w-5 h-5 animate-bounce" />
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-serif text-[#0F1419] mb-4">
              L'excellence <span className="text-[#C9A961]">Rolex</span>
            </h2>
            <p className="text-[#8B8680] max-w-2xl mx-auto">
              Chaque montre Rolex est le fruit d'un savoir-faire d'exception 
              et d'une recherche constante de la perfection.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="group p-8 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200 hover:border-[#C9A961]/50 transition-all hover:shadow-xl hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-[#C9A961]/10 flex items-center justify-center mb-6 group-hover:bg-[#C9A961]/20 transition-colors">
                <Shield className="w-7 h-7 text-[#C9A961]" />
              </div>
              <h3 className="text-xl font-semibold text-[#0F1419] mb-3">
                Certification Superlative
              </h3>
              <p className="text-[#8B8680]">
                Chaque mouvement est certifié chronomètre et testé dans nos laboratoires 
                pour garantir une précision exceptionnelle.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="group p-8 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200 hover:border-[#C9A961]/50 transition-all hover:shadow-xl hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-[#C9A961]/10 flex items-center justify-center mb-6 group-hover:bg-[#C9A961]/20 transition-colors">
                <Award className="w-7 h-7 text-[#C9A961]" />
              </div>
              <h3 className="text-xl font-semibold text-[#0F1419] mb-3">
                Matériaux d'Exception
              </h3>
              <p className="text-[#8B8680]">
                De l'Oystersteel à l'or 18 carats en passant par le platine 950, 
                nous n'utilisons que les matériaux les plus nobles.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="group p-8 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200 hover:border-[#C9A961]/50 transition-all hover:shadow-xl hover:-translate-y-1">
              <div className="w-14 h-14 rounded-xl bg-[#C9A961]/10 flex items-center justify-center mb-6 group-hover:bg-[#C9A961]/20 transition-colors">
                <Sparkles className="w-7 h-7 text-[#C9A961]" />
              </div>
              <h3 className="text-xl font-semibold text-[#0F1419] mb-3">
                Personnalisation Ultime
              </h3>
              <p className="text-[#8B8680]">
                Créez une montre qui vous ressemble avec des milliers de combinaisons 
                possibles de matériaux, cadrans et bracelets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-[#0F1419] to-[#1a2332]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-serif text-white mb-6">
            Prêt à créer votre <span className="text-[#C9A961]">montre unique</span> ?
          </h2>
          <p className="text-white/70 mb-8 max-w-2xl mx-auto">
            Commencez votre voyage de personnalisation dès maintenant. 
            Nos experts sont à votre disposition pour vous accompagner.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-4 rounded-xl bg-gradient-to-r from-[#C9A961] to-[#B8984F] text-white font-semibold shadow-lg shadow-[#C9A961]/30 hover:shadow-xl hover:shadow-[#C9A961]/40 hover:scale-[1.02] transition-all">
              Configurer ma montre
            </button>
            <button className="px-8 py-4 rounded-xl border-2 border-white/20 text-white font-semibold hover:border-[#C9A961] hover:text-[#C9A961] transition-colors">
              Trouver une boutique
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0F1419] border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <span className="text-2xl font-serif text-white tracking-wide">ROLEX</span>
              <span className="text-[#C9A961] text-xs uppercase tracking-[0.3em]">Configurator</span>
            </div>
            <p className="text-white/50 text-sm">
              © 2024 Rolex Configurator. Une expérience de luxe.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-white/50 hover:text-[#C9A961] text-sm transition-colors">Mentions légales</a>
              <a href="#" className="text-white/50 hover:text-[#C9A961] text-sm transition-colors">Confidentialité</a>
              <a href="#" className="text-white/50 hover:text-[#C9A961] text-sm transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
