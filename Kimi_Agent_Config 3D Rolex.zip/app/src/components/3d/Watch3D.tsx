import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Group, MeshStandardMaterial } from 'three';
import { useWatchStore, materialConfigs, dialConfigs, type StrapType } from '@/store/watchStore';

// Procedural Rolex Watch Component
export function Watch3D() {
  const groupRef = useRef<Group>(null);
  const { material, dialColor, strapType } = useWatchStore();
  
  // Auto-rotation
  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.1;
    }
  });

  // Material configurations
  const caseMaterial = useMemo(() => {
    const config = materialConfigs[material];
    return new MeshStandardMaterial({
      color: config.color,
      metalness: config.metalness,
      roughness: config.roughness,
      envMapIntensity: 1.5,
    });
  }, [material]);

  const dialMaterial = useMemo(() => {
    const config = dialConfigs[dialColor];
    return new MeshStandardMaterial({
      color: config.color,
      metalness: 0.3,
      roughness: 0.7,
      envMapIntensity: 0.5,
    });
  }, [dialColor]);

  const glassMaterial = useMemo(() => 
    new MeshStandardMaterial({
      color: '#FFFFFF',
      metalness: 0.1,
      roughness: 0.05,
      transparent: true,
      opacity: 0.3,
      envMapIntensity: 2,
    }), []
  );

  const markerMaterial = useMemo(() => 
    new MeshStandardMaterial({
      color: material === 'steel' ? '#C9A961' : '#FFFFFF',
      metalness: 0.9,
      roughness: 0.2,
      emissive: material === 'steel' ? '#C9A961' : '#FFFFFF',
      emissiveIntensity: 0.2,
    }), [material]
  );

  const handMaterial = useMemo(() => 
    new MeshStandardMaterial({
      color: material === 'steel' ? '#C9A961' : '#FFFFFF',
      metalness: 0.95,
      roughness: 0.15,
    }), [material]
  );

  // Generate hour markers
  const hourMarkers = useMemo(() => {
    const markers = [];
    for (let i = 0; i < 12; i++) {
      const angle = (i * 30 * Math.PI) / 180;
      const x = Math.sin(angle) * 1.15;
      const z = Math.cos(angle) * 1.15;
      const isCardinal = i % 3 === 0;
      markers.push(
        <mesh
          key={i}
          position={[x, 0.12, z]}
          rotation={[0, -angle, 0]}
          material={markerMaterial}
        >
          <boxGeometry args={[isCardinal ? 0.15 : 0.08, 0.04, isCardinal ? 0.25 : 0.15]} />
        </mesh>
      );
    }
    return markers;
  }, [markerMaterial]);

  return (
    <group ref={groupRef} position={[0, 0, 0]} rotation={[0.3, 0, 0]}>
      {/* Watch Case */}
      <mesh position={[0, 0, 0]} material={caseMaterial}>
        <cylinderGeometry args={[1.4, 1.4, 0.4, 64]} />
      </mesh>
      
      {/* Case Back */}
      <mesh position={[0, -0.25, 0]} material={caseMaterial}>
        <cylinderGeometry args={[1.3, 1.3, 0.1, 64]} />
      </mesh>
      
      {/* Bezel */}
      <mesh position={[0, 0.25, 0]} material={caseMaterial}>
        <torusGeometry args={[1.4, 0.12, 16, 100]} />
      </mesh>
      
      {/* Fluted bezel detail */}
      <mesh position={[0, 0.28, 0]} material={caseMaterial}>
        <torusGeometry args={[1.45, 0.06, 8, 120]} />
      </mesh>

      {/* Dial */}
      <mesh position={[0, 0.16, 0]} rotation={[-Math.PI / 2, 0, 0]} material={dialMaterial}>
        <circleGeometry args={[1.25, 64]} />
      </mesh>

      {/* Hour Markers */}
      {hourMarkers}

      {/* Crown Logo (simplified) */}
      <mesh position={[0, 0.18, -0.7]} material={markerMaterial}>
        <cylinderGeometry args={[0.12, 0.12, 0.02, 5]} />
      </mesh>

      {/* Hour Hand */}
      <mesh position={[0, 0.22, 0]} rotation={[0, 0, 0.5]} material={handMaterial}>
        <boxGeometry args={[0.08, 0.04, 0.7]} />
      </mesh>
      
      {/* Minute Hand */}
      <mesh position={[0, 0.24, 0]} rotation={[0, 0, -0.3]} material={handMaterial}>
        <boxGeometry args={[0.06, 0.04, 0.95]} />
      </mesh>
      
      {/* Second Hand */}
      <mesh position={[0, 0.26, 0]} rotation={[0, 0, 2]} material={new MeshStandardMaterial({ color: '#C9A961', metalness: 0.8, roughness: 0.3 })}>
        <boxGeometry args={[0.02, 0.04, 1.1]} />
      </mesh>
      
      {/* Center Cap */}
      <mesh position={[0, 0.28, 0]} material={caseMaterial}>
        <cylinderGeometry args={[0.08, 0.08, 0.05, 16]} />
      </mesh>

      {/* Date Window */}
      <mesh position={[0.7, 0.18, 0]} rotation={[0, 0, 0]} material={new MeshStandardMaterial({ color: '#FFFFFF', metalness: 0.1, roughness: 0.5 })}>
        <boxGeometry args={[0.25, 0.02, 0.35]} />
      </mesh>
      <mesh position={[0.7, 0.19, 0]} material={caseMaterial}>
        <boxGeometry args={[0.3, 0.04, 0.4]} />
      </mesh>

      {/* Crystal */}
      <mesh position={[0, 0.35, 0]} material={glassMaterial}>
        <cylinderGeometry args={[1.35, 1.35, 0.08, 64]} />
      </mesh>

      {/* Crown */}
      <mesh position={[1.45, 0, 0]} material={caseMaterial}>
        <cylinderGeometry args={[0.18, 0.18, 0.25, 16]} />
      </mesh>
      <mesh position={[1.5, 0, 0]} material={caseMaterial}>
        <cylinderGeometry args={[0.12, 0.12, 0.2, 8]} />
      </mesh>

      {/* Lugs */}
      <mesh position={[-1.3, -0.1, 0]} rotation={[0, 0, -0.3]} material={caseMaterial}>
        <boxGeometry args={[0.6, 0.3, 0.8]} />
      </mesh>
      <mesh position={[1.3, -0.1, 0]} rotation={[0, 0, 0.3]} material={caseMaterial}>
        <boxGeometry args={[0.6, 0.3, 0.8]} />
      </mesh>

      {/* Strap - Top */}
      <Strap position={[0, -0.2, -1.6]} rotation={[0.3, 0, 0]} type={strapType} material={caseMaterial} />
      
      {/* Strap - Bottom */}
      <Strap position={[0, -0.2, 1.6]} rotation={[-0.3, 0, Math.PI]} type={strapType} material={caseMaterial} />
    </group>
  );
}

// Strap Component
interface StrapProps {
  position: [number, number, number];
  rotation: [number, number, number];
  type: StrapType;
  material: MeshStandardMaterial;
}

// Strap component definition

function Strap({ position, rotation, type, material }: StrapProps) {
  if (type === 'leather') {
    return (
      <group position={position} rotation={rotation}>
        <mesh position={[0, 0, -0.8]} material={new MeshStandardMaterial({ color: '#3D2817', metalness: 0.1, roughness: 0.8 })}>
          <boxGeometry args={[1.0, 0.15, 1.6]} />
        </mesh>
        <mesh position={[0, 0, -2.2]} material={new MeshStandardMaterial({ color: '#3D2817', metalness: 0.1, roughness: 0.8 })}>
          <boxGeometry args={[0.9, 0.12, 1.2]} />
        </mesh>
        {/* Stitching */}
        <mesh position={[-0.4, 0.08, -0.8]} material={new MeshStandardMaterial({ color: '#C9A961' })}>
          <boxGeometry args={[0.02, 0.02, 1.5]} />
        </mesh>
        <mesh position={[0.4, 0.08, -0.8]} material={new MeshStandardMaterial({ color: '#C9A961' })}>
          <boxGeometry args={[0.02, 0.02, 1.5]} />
        </mesh>
      </group>
    );
  }

  // Metal bracelets (Oyster & Jubilee)
  const linkCount = 5;
  const links = [];
  
  for (let i = 0; i < linkCount; i++) {
    const z = -0.6 - i * 0.55;
    
    if (type === 'jubilee') {
      // Jubilee style - 5 smaller links
      links.push(
        <group key={i} position={[0, 0, z]}>
          <mesh position={[-0.25, 0, 0]} material={material}>
            <boxGeometry args={[0.22, 0.12, 0.5]} />
          </mesh>
          <mesh position={[0, 0, 0]} material={material}>
            <boxGeometry args={[0.22, 0.1, 0.5]} />
          </mesh>
          <mesh position={[0.25, 0, 0]} material={material}>
            <boxGeometry args={[0.22, 0.12, 0.5]} />
          </mesh>
        </group>
      );
    } else {
      // Oyster style - 3 larger links
      links.push(
        <group key={i} position={[0, 0, z]}>
          <mesh position={[-0.28, 0, 0]} material={material}>
            <boxGeometry args={[0.35, 0.15, 0.5]} />
          </mesh>
          <mesh position={[0.28, 0, 0]} material={material}>
            <boxGeometry args={[0.35, 0.15, 0.5]} />
          </mesh>
          <mesh position={[0, -0.02, 0]} material={material}>
            <boxGeometry args={[0.2, 0.12, 0.5]} />
          </mesh>
        </group>
      );
    }
  }

  return (
    <group position={position} rotation={rotation}>
      {links}
      {/* End link */}
      <mesh position={[0, 0, -3.5]} material={material}>
        <boxGeometry args={[0.5, 0.1, 0.6]} />
      </mesh>
    </group>
  );
}
