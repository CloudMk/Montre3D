import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { 
  Environment, 
  ContactShadows, 
  PresentationControls,
  PerspectiveCamera,
  Stars
} from '@react-three/drei';
import { Watch3D } from './Watch3D';

export function Scene3D() {
  return (
    <div className="w-full h-full">
      <Canvas
        shadows
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <Suspense fallback={<LoadingFallback />}>
          {/* Camera */}
          <PerspectiveCamera
            makeDefault
            position={[0, 0, 5]}
            fov={45}
            near={0.1}
            far={100}
          />
          
          {/* Lighting */}
          <ambientLight intensity={0.5} />
          
          {/* Main spotlight for shadows */}
          <spotLight
            position={[10, 10, 10]}
            angle={0.15}
            penumbra={1}
            intensity={1}
            castShadow
            shadow-mapSize={[2048, 2048]}
            shadow-bias={-0.0001}
          />
          
          {/* Fill lights */}
          <pointLight position={[-10, -10, -10]} intensity={0.3} color="#C9A961" />
          <pointLight position={[10, -10, 10]} intensity={0.3} color="#FFFFFF" />
          
          {/* Environment preset for reflections */}
          <Environment preset="city" background={false} />
          
          {/* Stars background */}
          <Stars
            radius={100}
            depth={50}
            count={5000}
            factor={4}
            saturation={0}
            fade
            speed={0.5}
          />
          
          {/* Presentation Controls for smooth interaction */}
          <PresentationControls
            global
            rotation={[0, 0, 0]}
            polar={[-0.4, 0.4]}
            azimuth={[-0.5, 0.5]}
            snap={true}
          >
            <Watch3D />
          </PresentationControls>
          
          {/* Contact shadows for realism */}
          <ContactShadows
            position={[0, -2, 0]}
            opacity={0.4}
            scale={10}
            blur={2.5}
            far={4}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

// Loading fallback component
function LoadingFallback() {
  return (
    <mesh>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="#C9A961" wireframe />
    </mesh>
  );
}
