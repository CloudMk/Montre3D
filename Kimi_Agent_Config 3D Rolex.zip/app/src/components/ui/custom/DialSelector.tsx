import { useWatchStore, dialConfigs, type DialColor } from '@/store/watchStore';
import { cn } from '@/lib/utils';

const dialColors: { value: DialColor; label: string }[] = [
  { value: 'black', label: 'Noir profond' },
  { value: 'blue', label: 'Bleu royal' },
  { value: 'green', label: 'Vert olive' },
  { value: 'white', label: 'Blanc perle' },
  { value: 'champagne', label: 'Champagne' },
  { value: 'brown', label: 'Chocolat' },
];

export function DialSelector() {
  const { dialColor, setDialColor } = useWatchStore();

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-[#8B8680] uppercase tracking-widest">
        Couleur du cadran
      </h3>
      <div className="flex flex-wrap gap-3">
        {dialColors.map((d) => {
          const config = dialConfigs[d.value];
          return (
            <button
              key={d.value}
              onClick={() => setDialColor(d.value)}
              className={cn(
                'group relative w-14 h-14 rounded-full border-3 transition-all duration-300',
                'hover:scale-110 hover:shadow-xl',
                dialColor === d.value
                  ? 'border-[#C9A961] scale-110 shadow-xl'
                  : 'border-slate-200 hover:border-[#C9A961]/50'
              )}
              style={{
                backgroundColor: config.color,
                boxShadow: dialColor === d.value 
                  ? `0 4px 20px ${config.color}60, inset 0 2px 8px rgba(255,255,255,0.3)`
                  : `inset 0 2px 8px rgba(255,255,255,0.2)`,
              }}
              title={d.label}
            >
              {/* Selected ring */}
              {dialColor === d.value && (
                <div className="absolute inset-0 rounded-full border-2 border-white/50" />
              )}
              
              {/* Checkmark */}
              {dialColor === d.value && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg 
                    className={cn(
                      'w-5 h-5',
                      d.value === 'white' || d.value === 'champagne' ? 'text-slate-800' : 'text-white'
                    )} 
                    fill="currentColor" 
                    viewBox="0 0 20 20"
                  >
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </button>
          );
        })}
      </div>
      <p className="text-sm text-slate-600 font-medium">
        {dialColors.find(d => d.value === dialColor)?.label}
      </p>
    </div>
  );
}
