import { useWatchStore, materialConfigs, type MaterialType } from '@/store/watchStore';
import { cn } from '@/lib/utils';

const materials: { value: MaterialType; label: string; description: string }[] = [
  { value: 'steel', label: 'Acier Oystersteel', description: 'Résistant et brillant' },
  { value: 'gold', label: 'Or jaune 18ct', description: 'Élégance intemporelle' },
  { value: 'rose-gold', label: 'Or Everose', description: 'Chaleur distinctive' },
  { value: 'platinum', label: 'Platine 950', description: 'Exclusivité absolue' },
];

export function MaterialSelector() {
  const { material, setMaterial } = useWatchStore();

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-[#8B8680] uppercase tracking-widest">
        Matériau du boîtier
      </h3>
      <div className="grid grid-cols-2 gap-3">
        {materials.map((m) => {
          const config = materialConfigs[m.value];
          return (
            <button
              key={m.value}
              onClick={() => setMaterial(m.value)}
              className={cn(
                'group relative p-4 rounded-xl border-2 transition-all duration-300',
                'hover:shadow-lg hover:scale-[1.02]',
                material === m.value
                  ? 'border-[#C9A961] bg-[#C9A961]/5 shadow-lg'
                  : 'border-slate-200 bg-white hover:border-[#C9A961]/50'
              )}
            >
              {/* Color preview */}
              <div
                className="w-10 h-10 rounded-full mb-3 mx-auto shadow-inner"
                style={{
                  backgroundColor: config.color,
                  boxShadow: `inset 0 2px 4px rgba(0,0,0,0.2), 0 2px 8px ${config.color}40`,
                }}
              />
              <p
                className={cn(
                  'text-sm font-semibold transition-colors',
                  material === m.value ? 'text-[#0F1419]' : 'text-slate-700'
                )}
              >
                {m.label}
              </p>
              <p className="text-xs text-[#8B8680] mt-1">{m.description}</p>
              
              {/* Selected indicator */}
              {material === m.value && (
                <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#C9A961] flex items-center justify-center">
                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
