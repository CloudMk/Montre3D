import { MaterialSelector } from './MaterialSelector';
import { DialSelector } from './DialSelector';
import { StrapSelector } from './StrapSelector';
import { useWatchStore } from '@/store/watchStore';
import { ShoppingBag, RotateCcw, Share2, Heart } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export function ControlPanel() {
  const { getPrice, material, dialColor, strapType } = useWatchStore();
  const [isLiked, setIsLiked] = useState(false);
  const price = getPrice();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="w-full max-w-md bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#0F1419] to-[#1a2332] p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[#C9A961] text-xs uppercase tracking-widest font-medium mb-1">
              Configurateur
            </p>
            <h2 className="text-2xl font-serif">Oyster Perpetual</h2>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setIsLiked(!isLiked)}
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                isLiked ? 'bg-red-500 text-white' : 'bg-white/10 hover:bg-white/20'
              )}
            >
              <Heart className={cn('w-5 h-5', isLiked && 'fill-current')} />
            </button>
            <button className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Scrollable content */}
      <div className="p-6 space-y-8 max-h-[50vh] overflow-y-auto custom-scrollbar">
        <MaterialSelector />
        <div className="h-px bg-gradient-to-r from-transparent via-slate-200 to-transparent" />
        <DialSelector />
        <div className="h-px bg-gradient-to-r from-transparent via-slate-200 to-transparent" />
        <StrapSelector />
      </div>

      {/* Footer with price and actions */}
      <div className="bg-slate-50 p-6 border-t border-slate-100">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-[#8B8680]">Prix total</p>
            <p className="text-3xl font-serif text-[#0F1419]">
              {formatPrice(price)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-[#8B8680]">Référence</p>
            <p className="text-sm font-mono text-[#0F1419]">
              126300-{material[0].toUpperCase()}{dialColor[0].toUpperCase()}{strapType[0].toUpperCase()}
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <button 
            onClick={() => window.location.reload()}
            className="px-4 py-3 rounded-xl border-2 border-slate-200 text-slate-600 hover:border-[#C9A961] hover:text-[#C9A961] transition-colors flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="text-sm font-medium">Réinitialiser</span>
          </button>
          <button className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-[#C9A961] to-[#B8984F] text-white font-semibold shadow-lg shadow-[#C9A961]/30 hover:shadow-xl hover:shadow-[#C9A961]/40 hover:scale-[1.02] transition-all flex items-center justify-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            <span>Ajouter au panier</span>
          </button>
        </div>
      </div>
    </div>
  );
}
