import type { LucideIcon } from 'lucide-react';
import { useWatchStore, type StrapType } from '@/store/watchStore';
import { cn } from '@/lib/utils';
import { Watch, CircleDot, Gem } from 'lucide-react';

const straps: { value: StrapType; label: string; description: string; icon: LucideIcon }[] = [
  { 
    value: 'oyster', 
    label: 'Bracelet Oyster', 
    description: 'Robuste et sportif',
    icon: Watch 
  },
  { 
    value: 'jubilee', 
    label: 'Bracelet Jubilee', 
    description: 'Élégant et confortable',
    icon: CircleDot 
  },
  { 
    value: 'leather', 
    label: 'Cuir Alligator', 
    description: 'Raffinement classique',
    icon: Gem 
  },
];

export function StrapSelector() {
  const { strapType, setStrapType } = useWatchStore();

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-[#8B8680] uppercase tracking-widest">
        Type de bracelet
      </h3>
      <div className="space-y-2">
        {straps.map((s) => {
          const Icon = s.icon;
          return (
            <button
              key={s.value}
              onClick={() => setStrapType(s.value)}
              className={cn(
                'w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-300',
                'hover:shadow-lg hover:scale-[1.01]',
                strapType === s.value
                  ? 'border-[#C9A961] bg-[#C9A961]/5 shadow-lg'
                  : 'border-slate-200 bg-white hover:border-[#C9A961]/50'
              )}
            >
              {/* Icon */}
              <div
                className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center transition-colors',
                  strapType === s.value 
                    ? 'bg-[#C9A961] text-white' 
                    : 'bg-slate-100 text-slate-500 group-hover:bg-[#C9A961]/20'
                )}
              >
                <Icon className="w-6 h-6" />
              </div>
              
              {/* Text */}
              <div className="flex-1 text-left">
                <p
                  className={cn(
                    'font-semibold transition-colors',
                    strapType === s.value ? 'text-[#0F1419]' : 'text-slate-700'
                  )}
                >
                  {s.label}
                </p>
                <p className="text-sm text-[#8B8680]">{s.description}</p>
              </div>
              
              {/* Radio indicator */}
              <div
                className={cn(
                  'w-5 h-5 rounded-full border-2 transition-all',
                  strapType === s.value
                    ? 'border-[#C9A961] bg-[#C9A961]'
                    : 'border-slate-300'
                )}
              >
                {strapType === s.value && (
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-white" />
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
